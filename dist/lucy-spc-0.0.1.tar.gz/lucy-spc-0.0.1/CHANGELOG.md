# Change Log

## 0.0.1 (12/03/2024)

- Initial version. basic read and write functionality.
